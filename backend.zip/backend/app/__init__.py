"""
Numerical Methods Application
Implements Harshad numbers and polynomial root-finding algorithms.
"""

__version__ = "1.0.0"
